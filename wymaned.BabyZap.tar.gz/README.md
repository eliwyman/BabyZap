To run:

make clean
make
make java
